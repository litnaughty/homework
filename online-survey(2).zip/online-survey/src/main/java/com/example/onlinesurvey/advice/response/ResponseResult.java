package com.example.onlinesurvey.advice.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 小鬼
 * @date 2022/11/19 18:41
 */
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class ResponseResult {
    private int code;
    private String message;
}

package com.example.onlinesurvey.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author 小鬼
 * @date 2022/11/19 16:50
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class QuestionDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 批次号
     */
    @NotNull(message = "批次号不允许为空", groups = updateValid.class)
    private Long id;

    /**
     * 问卷标题
     */
    @NotBlank(message = "问卷标题不允许为空", groups = {insertValid.class, updateValid.class})
    private String title;

    /**
     * 说明
     */
    private String remark;

    /**
     * 操作员ID
     */
    @NotNull(message = "操作员ID不允许为空", groups = {insertValid.class, updateValid.class})
    private Long empId;

    /**
     * 明细列表
     */
    @Valid
    private List<QuestionDetailDto> details;

    public @interface insertValid {
    }

    public @interface updateValid {
    }
}

package com.example.onlinesurvey.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author 小鬼
 * @date 2022/11/19 16:50
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class QuestionDetailDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 题目类型(1:选择题;2:填空题;3:是非题)
     */
    @NotNull(message = "题目类型不允许为空", groups = {QuestionDto.insertValid.class, QuestionDto.updateValid.class})
    private Long topicType;

    /**
     * 题目
     */
    @NotBlank(message = "题目不允许为空", groups = {QuestionDto.insertValid.class, QuestionDto.updateValid.class})
    private String topic;

    /**
     * 选项列表
     */
    @Valid
    private List<QuestionValueDto> values;
}

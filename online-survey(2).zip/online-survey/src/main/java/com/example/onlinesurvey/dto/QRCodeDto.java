package com.example.onlinesurvey.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author 小鬼
 * @date 2022/11/26 18:14
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class QRCodeDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @NotNull(message = "ID不允许为空", groups = updateQRCode.class)
    private Long id;

    /**
     * 跳转连接
     */
    @NotBlank(message = "跳转连接不允许为空", groups = {insertQRCode.class, updateQRCode.class})
    private String url;

    /**
     * 二维码高度
     */
    private Integer height;

    /**
     * 二维码宽度
     */
    private Integer wide;

    /**
     * 图片
     */
    private MultipartFile pictrue;

    public @interface insertQRCode {
    }

    public @interface updateQRCode {
    }
}

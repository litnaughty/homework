package com.example.onlinesurvey.enums;

import com.baomidou.mybatisplus.core.enums.IEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.stream.Stream;

/**
 * @author 小鬼
 * @date 2022/11/19 18:58
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum QuestionOptionsType implements IEnum<String> {
    QUESTION_CHOICE(1L, "选择题"),
    QUESTION_FILLING(2L, "填空题"),
    QUESTION_YES_NO(3L, "是非题");

    private Long code;
    private String desc;

    /**
     * 根据当前枚举的name匹配
     */
    public static QuestionOptionsType match(String val, QuestionOptionsType def) {
        return Stream.of(values()).parallel().filter(item -> item.name().equalsIgnoreCase(val)).findAny().orElse(def);
    }

    @Override
    public String getValue() {
        return null;
    }
}

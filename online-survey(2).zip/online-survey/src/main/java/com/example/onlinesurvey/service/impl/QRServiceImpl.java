package com.example.onlinesurvey.service.impl;

import cn.hutool.extra.qrcode.QrCodeUtil;
import cn.hutool.extra.qrcode.QrConfig;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.onlinesurvey.dto.QRCodeDto;
import com.example.onlinesurvey.entity.QRCode;
import com.example.onlinesurvey.mapper.QRCodeMapper;
import com.example.onlinesurvey.service.QRService;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * @author 小鬼
 * @date 2022/11/16 20:06
 */
@Slf4j
@Component
public class QRServiceImpl extends ServiceImpl<QRCodeMapper, QRCode> implements QRService {

    @Override
    public void generate(Long userId, HttpServletResponse response) throws IOException {
        QRCode qrCode = baseMapper.selectOne(new QueryWrapper<>());
        if (Objects.isNull(qrCode)) {
            log.error("未配置二维码相关参数！");
            throw new RuntimeException("请配置二维码相关参数！");
        }
        if (qrCode.getHeight() <= 0) {
            qrCode.setHeight(250);
        }
        if (qrCode.getWide() <= 0) {
            qrCode.setWide(250);
        }

        QrConfig config = QrConfig.create();
        config.setHeight(qrCode.getHeight());
        config.setWidth(qrCode.getWide());
        //背景色
        config.setBackColor(Color.white.getRGB());
        //前景色
        config.setForeColor(Color.black.getRGB());
        //边距
        config.setMargin(1);
        //纠错等级-高
        config.setErrorCorrection(ErrorCorrectionLevel.H);
        //logo
        byte[] img = qrCode.getPictrue();
        if (Objects.nonNull(img) &&
                img.length > 0) {
            InputStream in = new ByteArrayInputStream(img);
            config.setImg(ImageIO.read(in));
        }
        BufferedImage bufferedImage = QrCodeUtil.generate(qrCode.getUrl(), BarcodeFormat.QR_CODE, config);

        //设置响应头
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setContentType("image/png;charset=UTF-8");
        //文件名命名规则 时间戳(yyyyMMddHHmmss)
        String name = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".png";
        response.setHeader("Content-Disposition", "attachment;filename=" +
                URLEncoder.encode(name, "UTF-8"));

        FastByteArrayOutputStream out = null;
        OutputStream responseOut = null;
        InputStream inputStream = null;
        try {
            out = new FastByteArrayOutputStream();
            ImageIO.write(bufferedImage, "PNG", out);
            inputStream = out.getInputStream();
            responseOut = response.getOutputStream();

            //将二维码写入响应
            int bytes;
            while ((bytes = inputStream.read()) != -1) {
                responseOut.write(bytes);
            }
            response.flushBuffer();
        } finally {
            if (Objects.nonNull(inputStream)) {
                inputStream.close();
            }
            if (Objects.nonNull(responseOut)) {
                responseOut.close();
            }
            if (Objects.nonNull(out)) {
                out.close();
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateConfig(Long userId, QRCodeDto dto) {
        log.info("二维码设置更新开始--");
        QRCode qrCode = QRCode.builder().build();
        BeanUtils.copyProperties(dto, qrCode);
        qrCode.setUserId(userId);

        //图片设置处理
        MultipartFile file = dto.getPictrue();
        if (Objects.nonNull(file)) {
            try {
                qrCode.setPictrue(file.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //更新操作
        baseMapper.updateById(qrCode);
        log.info("二维码设置更新结束--");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addConfig(Long userId, QRCodeDto dto) {
        log.info("二维码设置开始--");

        //清除原有数据
        baseMapper.delete(new QueryWrapper<QRCode>().eq("USER_ID", userId));

        QRCode qrCode = QRCode.builder().build();
        BeanUtils.copyProperties(dto, qrCode);
        qrCode.setUserId(userId);

        //图片设置处理
        MultipartFile file = dto.getPictrue();
        if (Objects.nonNull(file)) {
            try {
                qrCode.setPictrue(file.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //新增操作
        baseMapper.insert(qrCode);
        log.info("二维码设置开结束--");
    }
}

package com.example.onlinesurvey.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.onlinesurvey.dto.QRCodeDto;
import com.example.onlinesurvey.entity.QRCode;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author 小鬼
 * @date 2022/11/16 20:07
 */
public interface QRService extends IService<QRCode> {
    /**
     * 生成二维码
     *
     * @param userId   用户ID
     * @param response 响应
     * @return void
     * @author 小鬼
     * @date 2022/11/16 20:11
     **/
    void generate(Long userId, HttpServletResponse response) throws IOException;

    /**
     * 二维码参数修改
     *
     * @param dto
     * @return void
     * @author 小鬼
     * @date 2022/11/26 18:22
     **/
    void updateConfig(Long userId, QRCodeDto dto);

    /**
     * 二维码参数设置
     *
     * @param dto
     * @return void
     * @author 小鬼
     * @date 2022/11/26 18:22
     **/
    void addConfig(Long userId, QRCodeDto dto);
}

package com.example.onlinesurvey.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.onlinesurvey.dto.QuestionDto;
import com.example.onlinesurvey.entity.QuestionBatch;

/**
 * @author 小鬼
 * @date 2022/11/19 16:30
 */
public interface QuestionService extends IService<QuestionBatch> {
    /**
     * 创建问卷
     *
     * @param dto
     * @return java.lang.String
     * @author 小鬼
     * @date 2022/11/19 19:14
     **/
    String createQuestion(QuestionDto dto);

    /**
     * 修改问卷
     *
     * @param dto
     * @return java.lang.String
     * @author 小鬼
     * @date 2022/11/19 19:14
     **/
    String modifyQuestion(QuestionDto dto);
}

package com.example.onlinesurvey.controller;

import com.example.onlinesurvey.dto.QRCodeDto;
import com.example.onlinesurvey.service.QRService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 二维码参数设置相关
 *
 * @author 小鬼
 * @date 2022/11/16 20:04
 */
@Slf4j
@RestController
@RequestMapping(value = "/qrcode")
public class QRCodeController {
    @Autowired
    private QRService qrService;

    /**
     * 生成二维码,并返回给调用方
     *
     * @param userId   用户ID
     * @param response 响应
     * @return void
     * @author 小鬼
     * @date 2022/11/19 16:28
     **/
    @RequestMapping(value = "/generate", method = RequestMethod.GET, produces = "image/png;charset=UTF-8")
    public void generate(@RequestHeader Long userId, HttpServletResponse response) throws IOException {
        qrService.generate(userId, response);
    }

    /**
     * 二维码参数设置
     *
     * @param dto
     * @return void
     * @author 小鬼
     * @date 2022/11/26 18:18
     **/
    @RequestMapping(value = "/addConfig", method = RequestMethod.POST)
    public void addConfig(@RequestHeader Long userId,
                          @ModelAttribute @Validated(value = QRCodeDto.insertQRCode.class) QRCodeDto dto) {
        qrService.addConfig(userId, dto);
    }

    /**
     * 二维码参数修改
     *
     * @param dto
     * @return void
     * @author 小鬼
     * @date 2022/11/26 18:18
     **/
    @RequestMapping(value = "/modfiyConfig", method = RequestMethod.POST)
    public void updateConfig(@RequestHeader Long userId,
                             @ModelAttribute @Validated(value = QRCodeDto.updateQRCode.class) QRCodeDto dto) {
        qrService.updateConfig(userId, dto);
    }
}

package com.example.onlinesurvey.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 问卷选择项枚举表
 *
 * @author 小鬼
 * @date 2022/11/19 16:34
 */
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "question_enum")
@Data
@Builder
public class QuestionValue implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Long id;

    /**
     * 批次号
     */
    @TableField(value = "BATCH_ID")
    private Long batchId;

    /**
     * 明细ID
     */
    @TableField(value = "DETAIL_ID")
    private Long detailId;

    /**
     * 选项编码
     */
    @TableField(value = "OPTION_CODE")
    private String optionCode;

    /**
     * 选项内容
     */
    @TableField(value = "OPTION_VALUE")
    private String optionValue;

    /**
     * 说明
     */
    @TableField(value = "REAMRK")
    private String remark;
}

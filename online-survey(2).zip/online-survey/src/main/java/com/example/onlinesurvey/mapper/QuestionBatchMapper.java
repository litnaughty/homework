package com.example.onlinesurvey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.onlinesurvey.entity.QRCode;
import com.example.onlinesurvey.entity.QuestionBatch;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 小鬼
 * @date 2022/11/16 20:50
 */
@Mapper
public interface QuestionBatchMapper extends BaseMapper<QuestionBatch> {
}

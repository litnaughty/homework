package com.example.onlinesurvey.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.onlinesurvey.entity.QuestionDetail;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 小鬼
 * @date 2022/11/16 20:50
 */
@Mapper
public interface QuestionDetailMapper extends BaseMapper<QuestionDetail> {
}

package com.example.onlinesurvey.advice;

import com.example.onlinesurvey.advice.response.ResponseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.ServletRequest;
import java.util.List;

/**
 * @author 小鬼
 * @date 2022/11/19 18:30
 */
@Slf4j
@RestControllerAdvice(basePackages = "com.example.onlinesurvey.controller")
public class GlobalExceptionHandler {
    /**
     * 自定义验证异常
     * MethodArgumentNotValidException 方法参数无效异常
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST) //设置状态码为 400
    @ExceptionHandler({MethodArgumentNotValidException.class})
    public ResponseResult paramExceptionHandler(MethodArgumentNotValidException exception, ServletRequest request) {
        BindingResult result = exception.getBindingResult();
        StringBuilder stringBuilder = new StringBuilder();
        if (result.hasErrors()) {
            List<ObjectError> errors = result.getAllErrors();
            if (errors != null) {
                errors.forEach(p -> {
                    FieldError fieldError = (FieldError) p;
                    stringBuilder.append(fieldError.getDefaultMessage() + "|");
                });
            }
        }
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        ResponseResult responseResult = ResponseResult.builder()
                .code(HttpStatus.BAD_REQUEST.value())
                .message(stringBuilder.toString())
                .build();
        return responseResult;
    }
}

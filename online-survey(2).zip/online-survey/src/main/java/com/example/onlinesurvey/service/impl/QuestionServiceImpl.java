package com.example.onlinesurvey.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.onlinesurvey.dto.QuestionDetailDto;
import com.example.onlinesurvey.dto.QuestionDto;
import com.example.onlinesurvey.dto.QuestionValueDto;
import com.example.onlinesurvey.entity.QuestionBatch;
import com.example.onlinesurvey.entity.QuestionDetail;
import com.example.onlinesurvey.entity.QuestionValue;
import com.example.onlinesurvey.enums.QuestionOptionsType;
import com.example.onlinesurvey.mapper.QuestionBatchMapper;
import com.example.onlinesurvey.mapper.QuestionDetailMapper;
import com.example.onlinesurvey.mapper.QuestionValueMapper;
import com.example.onlinesurvey.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

/**
 * 问卷调查相关
 *
 * @author 小鬼
 * @date 2022/11/19 16:31
 */
@Slf4j
@Component
public class QuestionServiceImpl extends ServiceImpl<QuestionBatchMapper, QuestionBatch> implements QuestionService {
    @Autowired
    private QuestionDetailMapper detailMapper;
    @Autowired
    private QuestionValueMapper valueMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String createQuestion(QuestionDto dto) {
        log.info("开始创建问卷---");

        List<QuestionDetailDto> detailDtos = dto.getDetails();
        detailDtos.stream().forEach(detailDto -> {
            if (QuestionOptionsType.QUESTION_CHOICE.getCode() == detailDto.getTopicType() &&
                    (Objects.isNull(detailDto.getValues()) || detailDto.getValues().isEmpty())) {
                throw new RuntimeException("题目类型为选择题时,选项列表不允许为空");
            }
        });

        QuestionBatch batch = QuestionBatch.builder()
                .title(dto.getTitle())
                .remark(dto.getRemark())
                .createId(dto.getEmpId())
                .createTime(LocalDateTime.now())
                .build();
        baseMapper.insert(batch);
        Long batchNo = batch.getId();

        detailDtos.stream().forEach(detailDto -> {
            QuestionDetail detail = QuestionDetail.builder()
                    .batchId(batchNo)
                    .topicType(detailDto.getTopicType())
                    .topic(detailDto.getTopic())
                    .build();
            detailMapper.insert(detail);
            Long detailId = detail.getId();

            if (QuestionOptionsType.QUESTION_CHOICE.getCode() == detailDto.getTopicType()) {
                List<QuestionValueDto> valueDtos = detailDto.getValues();
                valueDtos.stream().forEach(valueDto -> {
                    QuestionValue value = QuestionValue.builder()
                            .optionCode(valueDto.getOptionCode())
                            .optionValue(valueDto.getOptionValue())
                            .batchId(batchNo)
                            .detailId(detailId)
                            .build();
                    valueMapper.insert(value);
                });
            }
        });

        log.info("创建问卷结束---");
        return "创建问卷成功！";
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String modifyQuestion(QuestionDto dto) {
        log.info("修改问卷开始---");
        List<QuestionDetailDto> detailDtos = dto.getDetails();
        detailDtos.stream().forEach(detailDto -> {
            if (QuestionOptionsType.QUESTION_CHOICE.getCode() == detailDto.getTopicType() &&
                    (Objects.isNull(detailDto.getValues()) || detailDto.getValues().isEmpty())) {
                throw new RuntimeException("题目类型为选择题时,选项列表不允许为空");
            }
        });

        QuestionBatch batch = QuestionBatch.builder()
                .id(dto.getId())
                .title(dto.getTitle())
                .remark(dto.getRemark())
                .updateId(dto.getEmpId())
                .updateTime(LocalDateTime.now())
                .build();
        baseMapper.updateById(batch);
        Long batchNo = batch.getId();

        detailMapper.delete(new QueryWrapper<QuestionDetail>().eq("BATCH_ID", batchNo));
        valueMapper.delete(new QueryWrapper<QuestionValue>().eq("BATCH_ID", batchNo));

        detailDtos.stream().forEach(detailDto -> {
            QuestionDetail detail = QuestionDetail.builder()
                    .batchId(batchNo)
                    .topicType(detailDto.getTopicType())
                    .topic(detailDto.getTopic())
                    .build();
            detailMapper.insert(detail);
            Long detailId = detail.getId();

            if (QuestionOptionsType.QUESTION_CHOICE.getCode() == detailDto.getTopicType()) {
                List<QuestionValueDto> valueDtos = detailDto.getValues();
                valueDtos.stream().forEach(valueDto -> {
                    QuestionValue value = QuestionValue.builder()
                            .optionCode(valueDto.getOptionCode())
                            .optionValue(valueDto.getOptionValue())
                            .batchId(batchNo)
                            .detailId(detailId)
                            .build();
                    valueMapper.insert(value);
                });
            }
        });

        log.info("修改问卷结束---");
        return "修改问卷成功！";
    }
}

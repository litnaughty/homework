package com.example.onlinesurvey.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author 小鬼
 * @date 2022/11/19 16:50
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class QuestionValueDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 选项编码
     */
    @NotBlank(message = "选项编码不允许为空", groups = {QuestionDto.insertValid.class, QuestionDto.updateValid.class})
    private String optionCode;

    /**
     * 选项内容
     */
    @NotBlank(message = "选项内容不允许为空", groups = {QuestionDto.insertValid.class, QuestionDto.updateValid.class})
    private String optionValue;

    /**
     * 说明
     */
    private String remark;
}

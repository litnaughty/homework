package com.example.onlinesurvey.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 问卷批次表
 *
 * @author 小鬼
 * @date 2022/11/19 16:34
 */
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "question_batch")
@Data
@Builder
public class QuestionBatch implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 批次号
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Long id;

    /**
     * 问卷标题
     */
    @TableField(value = "TITLE")
    private String title;

    /**
     * 说明
     */
    @TableField(value = "REAMRK")
    private String remark;

    /**
     * 创建时间
     */
    @TableField(value = "CREATE_TIME")
    private LocalDateTime createTime;

    /**
     * 创建人ID
     */
    @TableField(value = "CREATE_ID")
    private Long createId;

    /**
     * 更新时间
     */
    @TableField(value = "UPDATE_TIME")
    private LocalDateTime updateTime;

    /**
     * 更新人ID
     */
    @TableField(value = "UPDATE_ID")
    private Long updateId;
}

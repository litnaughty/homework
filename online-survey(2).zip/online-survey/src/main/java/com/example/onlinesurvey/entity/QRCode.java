package com.example.onlinesurvey.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 二维码设置相关
 *
 * @author 小鬼
 * @date 2022/11/16 20:44
 */
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "qr_code_set")
@Data
@Builder
public class QRCode implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Long id;

    /**
     * 跳转连接
     */
    @TableField(value = "URL")
    private String url;

    /**
     * 二维码高度
     */
    @TableField(value = "HEIGHT")
    private Integer height;

    /**
     * 二维码宽度
     */
    @TableField(value = "WIDE")
    private Integer wide;

    /**
     * 图片
     */
    @TableField(value = "PICTRUE")
    private byte[] pictrue;

    /**
     * 用户ID
     */
    @TableField(value = "USER_ID")
    private Long userId;
}

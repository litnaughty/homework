package com.example.onlinesurvey.controller;

import com.example.onlinesurvey.dto.QuestionDto;
import com.example.onlinesurvey.service.QuestionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 问卷设置相关
 *
 * @author 小鬼
 * @date 2022/11/19 16:27
 */
@Slf4j
@Validated
@RestController
@RequestMapping(value = "/question")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    /**
     * 创建问卷
     *
     * @param dto
     * @return java.lang.String
     * @author 小鬼
     * @date 2022/11/19 19:14
     **/
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String createQuestion(@RequestBody @Validated(value = QuestionDto.insertValid.class) QuestionDto dto) {
        return questionService.createQuestion(dto);
    }

    /**
     * 修改问卷
     *
     * @param dto
     * @return void
     * @author 小鬼
     * @date 2022/11/19 16:53
     **/
    @RequestMapping(value = "/modify", method = RequestMethod.POST)
    public String modeifyQuestion(@RequestBody @Validated(value = QuestionDto.updateValid.class) QuestionDto dto) {
        return questionService.modifyQuestion(dto);
    }
}

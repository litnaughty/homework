package com.example.onlinesurvey.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 问卷明细表
 *
 * @author 小鬼
 * @date 2022/11/19 16:34
 */
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "question_detail")
@Data
@Builder
public class QuestionDetail implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 明细ID
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Long id;

    /**
     * 批次号
     */
    @TableField(value = "BATCH_ID")
    private Long batchId;

    /**
     * 题目类型(1:选择题;2:填空题;3:是非题)
     */
    @TableField(value = "TOPIC_TYPE")
    private Long topicType;

    /**
     * 题目
     */
    @TableField(value = "TOPIC")
    private String topic;

    /**
     * 作答结果
     */
    @TableField(value = "RESULT")
    private String result;
}
